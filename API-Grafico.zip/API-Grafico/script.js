var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
//fetch = require("node-fetch");
const cors = require('cors')
const dotenv = require("dotenv").config()
const express = require('express');
const app = express();

let API = "https://api.kentik.com/api/v5/query/topxdata"

app.use(cors())

app.get('/consultar/dados/:start&:end', function(req, res) {

    let start_time = req.params.start 
    let end_time = req.params.end

    let time = {
      starting_time: start_time,
      ending_time: end_time,
    }

    let res_sent = res
    getData(time)

    // %20 = espaço em branco
    function getData(time){

      let value =  {"version":4,"queries":[{"bucket":"Flow","query":{"all_devices":false,"aggregateTypes":["avg_bits_per_sec","p95th_bits_per_sec","max_bits_per_sec"],"aggregateThresholds":{"avg_bits_per_sec":0,"p95th_bits_per_sec":0,"max_bits_per_sec":0},"bracketOptions":"","hideCidr":false,"cidr":32,"cidr6":128,"customAsGroups":true,"cutFn":{},"cutFnRegex":{},"cutFnSelector":{},"depth":75,"descriptor":"","device_name":["an_frl01"],"device_labels":[],"device_sites":[],"device_types":[],"fastData":"Auto","filterDimensionsEnabled":false,"filterDimensionName":"Total","filterDimensionOther":false,"filterDimensionSort":false,"filterDimensions":{},"aggregateFiltersEnabled":false,"aggregateFiltersDimensionLabel":"","aggregateFilters":[],"hostname_lookup":true,"isOverlay":false,"lookback_seconds":0,"from_to_lookback":3600,"generatorDimensions":[],"generatorPanelMinHeight":250,"generatorMode":false,"generatorColumns":1,"generatorQueryTitle":"{{generator_series_name}}","generatorTopx":8,"matrixBy":[],"metric":["bytes"],"forceMinsPolling":false,"mirror":false,"mirrorUnits":true,"outsort":"avg_bits_per_sec","overlay_timestamp_adjust":false,"query_title":"","secondaryOutsort":"","secondaryTopxSeparate":false,"secondaryTopxMirrored":false,"show_total_overlay":true,"starting_time": time.starting_time,"ending_time": time.ending_time,"sync_all_axes":false,"sync_extents":true,"show_site_markers":false,"topx":8,"update_frequency":0,"use_log_axis":false,"use_secondary_log_axis":false,"aggregates":[{"value":"avg_bits_per_sec","column":"f_sum_both_bytes","fn":"average","label":"Bits/s Sampled at Ingress + Egress Average","unit":"bytes","group":"Bits/s Sampled at Ingress + Egress","origLabel":"Average","sample_rate":1,"raw":true,"name":"avg_bits_per_sec"},{"value":"p95th_bits_per_sec","column":"f_sum_both_bytes","fn":"percentile","label":"Bits/s Sampled at Ingress + Egress 95th Percentile","rank":95,"unit":"bytes","group":"Bits/s Sampled at Ingress + Egress","origLabel":"95th Percentile","sample_rate":1,"name":"p95th_bits_per_sec"},{"value":"max_bits_per_sec","column":"f_sum_both_bytes","fn":"max","label":"Bits/s Sampled at Ingress + Egress Max","unit":"bytes","group":"Bits/s Sampled at Ingress + Egress","origLabel":"Max","sample_rate":1,"name":"max_bits_per_sec"}],"filters":{"connector":"All","filterGroups":[]},"dimension":["AS_src","AS_dst"]}}]}

      var xhr = new XMLHttpRequest();
      xhr.open("POST", API);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.setRequestHeader('X-CH-Auth-API-Token', process.env.KEY);
      xhr.setRequestHeader('X-CH-Auth-Email', process.env.EMAIL)
      xhr.setRequestHeader('Access-Control-Allow-Credentials', 'true');
      xhr.setRequestHeader('Access-Control-Allow-Headers', 'Authorization, origin, accept')
      xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
          console.log(xhr.status);
              var data = xhr.responseText;
              var jsonResponse = JSON.parse(data);
              res_sent.json(jsonResponse)
              console.log(jsonResponse.results[0].data)
      }};
      xhr.send(JSON.stringify(value));
      var body = XMLHttpRequest.response;
  }

});

app.listen(3000, () => {
    console.log("Server running....")
});
